<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>HR Desi</title>
	<link rel="stylesheet" href="style.css">
	<link rel="shortcut icon" href="fevicon.png" type="image/x-icon">
</head>

<body>
	<header>
		<nav id="navbar">

			<div>
				<button id="sign">Sign In</button>
				<!-- type="submit" id="sign" value="Sign In"> -->
			</div>
			<ul>
				<li><a href="#"> Images</a></li>
				<li><a href="#">Gmail</a> </li>

			</ul>

		</nav>
	</header>
	</div>
	<img src="logo.png" alt="Logo" id="logo">
	<form action='result.php' method='GET'>
		<div id="design">
			<img src="https://img.icons8.com/ios/50/000000/search--v5.png" alt="Search" id="srclogo">
			<center><input type="text" id="searchfield" name="searchbar"></center>
			<img src="mic.png" alt="" id="mic">
			<!-- <img src="mic.png" alt="" id="mic"> -->
			<!-- <button id="feeling">I'm Feeling Lucky</button> -->
			<!-- <center><input type="submit" id="searchbtn" name="searchbtn" value="Google Search"></center> -->
		</div>
		<center><input type="submit" id="srcbtn" name="searchbtn" value="Google Search"></center>
		<!-- <center><button id="srcbtn">Google Search</button></center> -->
	</form>
</body>

</html>