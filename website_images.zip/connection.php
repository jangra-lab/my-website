<?php


$servername = 'localhost';
$username = 'thesecur_root';
$password = 'Im@sahil';
$dbname = 'thesecur_mysite';

$conn = mysqli_connect($servername,$username,$password,$dbname);

?>